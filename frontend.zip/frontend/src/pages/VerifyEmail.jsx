import { useEffect, useState } from 'react'
import { useLocation, Link } from 'react-router-dom'
import { verifyEmailApi } from '../api/auth.js'

export default function VerifyEmail() {
  const location = useLocation()
  const [status, setStatus] = useState('loading')
  const [message, setMessage] = useState('Verifying…')

  useEffect(() => {
    const params = new URLSearchParams(location.search)
    const token = params.get('token')
    const email = params.get('email')
    if (!token || !email) {
      setStatus('error')
      setMessage('Invalid verification link')
      return
    }
    verifyEmailApi({ token, email })
      .then((res) => {
        setStatus('success')
        setMessage(res.message || 'Email verified successfully')
      })
      .catch((err) => {
        setStatus('error')
        setMessage(err.message || 'Verification failed')
      })
  }, [location.search])

  return (
    <div>
      <h1>Email Verification</h1>
      <p style={{ marginTop: 12, color: status === 'error' ? 'crimson' : 'inherit' }}>{message}</p>
      <p style={{ marginTop: 12 }}>
        <Link to="/signup">Back to Signup</Link>
      </p>
    </div>
  )
}


