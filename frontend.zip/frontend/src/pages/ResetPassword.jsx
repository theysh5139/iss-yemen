import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { resetPasswordApi } from '../api/auth.js'

export default function ResetPassword() {
  const location = useLocation()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [token, setToken] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  useEffect(() => {
    const params = new URLSearchParams(location.search)
    const t = params.get('token')
    const e = params.get('email')
    if (t) setToken(t)
    if (e) setEmail(e)
  }, [location.search])

  function validate() {
    if (!token || !email) return 'Invalid reset link'
    if (newPassword.length < 8) return 'Password must be at least 8 characters'
    if (!/[A-Z]/.test(newPassword) || !/[a-z]/.test(newPassword) || !/\d/.test(newPassword)) {
      return 'Password must include upper, lower, and a digit'
    }
    if (newPassword !== confirmPassword) return 'Passwords must match'
    return ''
  }

  async function onSubmit(e) {
    e.preventDefault()
    setError('')
    setMessage('')
    const v = validate()
    if (v) return setError(v)
    setLoading(true)
    try {
      const res = await resetPasswordApi({ token, email, newPassword, confirmPassword })
      setMessage(res.message || 'Password reset successful')
      setNewPassword('')
      setConfirmPassword('')
      setTimeout(() => navigate('/login', { replace: true }), 1200)
    } catch (err) {
      setError(err.message || 'Reset failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h1>Reset Password</h1>
      <form onSubmit={onSubmit} style={{ display: 'grid', gap: 12, marginTop: 16 }}>
        <label>
          New password
          <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
        </label>
        <label>
          Confirm password
          <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
        </label>
        <button type="submit" disabled={loading}>{loading ? 'Resetting…' : 'Reset password'}</button>
      </form>
      {error && <p style={{ color: 'crimson', marginTop: 12 }}>{error}</p>}
      {message && <p style={{ color: 'green', marginTop: 12 }}>{message}</p>}
    </div>
  )
}


