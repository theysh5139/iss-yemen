import { useAuth } from '../context/AuthProvider.jsx'
import { logoutApi } from '../api/auth.js'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const { user, setUser } = useAuth()
  const navigate = useNavigate()

  async function onLogout() {
    try {
      await logoutApi()
    } catch {}
    setUser(null)
    navigate('/login', { replace: true })
  }
  return (
    <div>
      <h1>Welcome{user?.name ? `, ${user.name}` : ''}!</h1>
      <p style={{ marginTop: 12 }}>This is your dashboard.</p>
      <button style={{ marginTop: 16 }} onClick={onLogout}>Log out</button>
    </div>
  )
}


